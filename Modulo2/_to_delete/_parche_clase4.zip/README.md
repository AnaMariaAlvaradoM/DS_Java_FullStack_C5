# VetCare · Software para clínicas veterinarias

Sistema web para gestionar una clínica veterinaria: agenda del día, pacientes, dueños, historia clínica, equipo médico e ingresos. Cada persona del equipo ve solo lo que necesita según su rol.

Proyecto final del Módulo 2 del programa **Java Full Stack Developer** de Dev Senior Code.

## Qué hace cada rol

| Rol | Puede |
|---|---|
| **Administración** | Ver el panel del negocio (citas, ingresos, cancelaciones, rendimiento del equipo), gestionar veterinarios, crear cuentas del personal, eliminar registros y todo lo de recepción |
| **Recepción** | Ver la agenda de la clínica, agendar y cancelar citas, registrar dueños y pacientes |
| **Veterinario** | Ver **su** agenda, atender citas registrando diagnóstico y costo, consultar la historia clínica de cada paciente |

## Tecnologías

- **Backend:** Java 17, Spring Boot 4, Spring Security con JWT (jjwt), Spring Data JPA, PostgreSQL, Bean Validation, SpringDoc OpenAPI (Swagger).
- **Frontend:** Angular 21 (componentes standalone, Signals, `effect`, guards e interceptores funcionales), TypeScript, HTML semántico y CSS con sistema de diseño propio (sin librerías de UI).

## Funcionalidades destacadas

- Login con JWT, redirección según el rol y **cierre automático** de la sesión cuando el token vence.
- Rutas protegidas por sesión (`authGuard`) y por rol (`rolGuard`); páginas públicas que se cierran con sesión (`invitadoGuard`); página 404.
- Interceptor que adjunta el token a cada petición y cierra la sesión ante un `401`.
- Datos que siguen a la sesión: se cargan al entrar y se limpian al salir.
- Agenda por día con navegación, agendar, cancelar (con diálogo de confirmación) y atender.
- Historia clínica en línea de tiempo por paciente.
- Panel de administración con indicadores y gráfica de ingresos de los últimos 7 días.
- Gestión de veterinarios y cuentas del personal.
- Avisos accesibles (`aria-live`), diálogo nativo `<dialog>`, formularios con etiquetas, diseño adaptable a celular.
- Backend con errores honestos (`400`, `401`, `403`, `404`, `409`) y reglas de negocio que protegen la historia clínica.

## Cómo levantarlo

### Requisitos

Java 17 o superior, Node.js 20 o superior, PostgreSQL con una base de datos llamada `vetcare_db` (usuario `postgres`, clave `admin`, configurables en `backend/src/main/resources/application.properties`).

### Backend

```bash
cd backend
mvnw.cmd spring-boot:run        # Windows
./mvnw spring-boot:run          # macOS / Linux
```

Queda en `http://localhost:8080`. Documentación interactiva: `http://localhost:8080/swagger-ui.html`. Al arrancar por primera vez crea las tablas y siembra datos de demostración.

### Frontend

```bash
cd frontend
npm install
npm start
```

Queda en `http://localhost:4200`.

## Usuarios de demostración

Todos con la contraseña `vetcare123`.

| Usuario | Rol | Nombre |
|---|---|---|
| `admin` | Administración | Carolina Rojas |
| `recepcion` | Recepción | Juliana Pérez |
| `dra.gomez` | Veterinario | Laura Gómez |
| `dr.ruiz` | Veterinario | Andrés Ruiz |

La veterinaria Paula Mejía no tiene cuenta: créala desde **Personal** con el usuario `admin`.

## Estructura

```text
backend/   API REST Spring Boot (controller → service → repository, DTO, seguridad JWT)
frontend/  SPA Angular (pages, components, services, guards, interceptors, core)
```

---

© 2026 Ana Alvarado · Educadora Tech & Desarrolladora Full Stack · linkedin.com/in/ana-alvarado-instructora-full-stack
